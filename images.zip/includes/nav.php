<nav class="navbar">
    <a class="nava lefta" href="/" data-link>home</a>
    <a class="nava" href="/dev" data-link>dev</a>
    <a class="nava" href="/else" data-link>else</a>
    <a class="nava" href="/about" data-link>about</a>
    <a class="nava righta" href="/contact" data-link>contact</a>
</nav>
