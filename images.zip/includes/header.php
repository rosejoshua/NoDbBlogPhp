<div class="header">
  <h1 class="headerh1">{&nbsp; jrose.me &nbsp;}</h1>
  <?php include('includes/nav.php') ?>
</div>
